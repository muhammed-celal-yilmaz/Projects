# Sıfırdan İleri Seviyeye Python Programlama


Udemy üzerindeki [Sıfırdan İleri Seviyeye Python Programlama](https://www.udemy.com/course/sifirdan-ileri-seviyeye-python/?couponCode=PYTHON6) kursundaki Çalışma Notebookları ve Kullanılan Kodlar


